package com.kelvin.pdf;
import android.content.Context;
import android.graphics.*;
import android.view.View;
public class IconView extends View {
    private final String name;private final int color;private final Paint p=new Paint(3);
    public IconView(Context c,String n,int col){super(c);name=n;color=col;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    protected void onDraw(Canvas real){Canvas c=real;int s=c.save();c.translate(getWidth()/2f,getHeight()/2f);float scale=Math.min(getWidth(),getHeight())/28f;c.scale(scale,scale);c.translate(-12,-12);p.setColor(color);p.setStrokeWidth(1.8f);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path a=new Path();
        switch(name){
        case "home":a.moveTo(3,10);a.lineTo(12,3);a.lineTo(21,10);a.moveTo(5,9);a.lineTo(5,21);a.lineTo(10,21);a.lineTo(10,15);a.lineTo(14,15);a.lineTo(14,21);a.lineTo(19,21);a.lineTo(19,9);c.drawPath(a,p);break;
        case "scan":case "camera":c.drawRoundRect(2,6,22,21,3,3,p);c.drawCircle(12,13,4,p);c.drawLine(7,6,9,3,p);c.drawLine(9,3,15,3,p);c.drawLine(15,3,17,6,p);break;
        case "plus":c.drawLine(12,4,12,20,p);c.drawLine(4,12,20,12,p);break;
        case "back":a.moveTo(15,4);a.lineTo(7,12);a.lineTo(15,20);c.drawPath(a,p);break;
        case "arrow":c.drawLine(3,12,21,12,p);a.moveTo(15,6);a.lineTo(21,12);a.lineTo(15,18);c.drawPath(a,p);break;
        case "import":c.drawRoundRect(3,3,21,21,2,2,p);c.drawLine(12,4,12,14,p);a.moveTo(8,10);a.lineTo(12,14);a.lineTo(16,10);c.drawPath(a,p);c.drawLine(7,18,17,18,p);break;
        case "settings":c.drawCircle(12,12,7,p);c.drawCircle(12,12,2.5f,p);for(int i=0;i<8;i++){double t=i*Math.PI/4;c.drawLine(12+7*(float)Math.cos(t),12+7*(float)Math.sin(t),12+10*(float)Math.cos(t),12+10*(float)Math.sin(t),p);}break;
        case "tools":c.drawRoundRect(3,3,10,10,2,2,p);c.drawRoundRect(14,3,21,10,2,2,p);c.drawRoundRect(3,14,10,21,2,2,p);c.drawRoundRect(14,14,21,21,2,2,p);break;
        case "more":p.setStyle(Paint.Style.FILL);for(int i=0;i<3;i++)c.drawCircle(12,5+i*7,1.4f,p);break;
        case "star":for(int i=0;i<10;i++){double t=-Math.PI/2+i*Math.PI/5;float r=i%2==0?10:4.5f;float x=12+r*(float)Math.cos(t),y=12+r*(float)Math.sin(t);if(i==0)a.moveTo(x,y);else a.lineTo(x,y);}a.close();c.drawPath(a,p);break;
        case "search":c.drawCircle(10,10,6,p);c.drawLine(15,15,21,21,p);break;
        case "rotate":c.drawArc(4,4,20,20,-70,290,false,p);a.moveTo(15,2);a.lineTo(19,6);a.lineTo(13,7);c.drawPath(a,p);break;
        case "crop":c.drawLine(6,2,6,18,p);c.drawLine(6,18,22,18,p);c.drawLine(2,6,18,6,p);c.drawLine(18,6,18,22,p);break;
        case "filter":c.drawCircle(12,12,9,p);c.save();c.clipRect(0,0,12,24);p.setStyle(Paint.Style.FILL);c.drawCircle(12,12,9,p);c.restore();break;
        case "delete":c.drawLine(3,6,21,6,p);c.drawLine(8,3,16,3,p);a.moveTo(5,6);a.lineTo(6,21);a.lineTo(18,21);a.lineTo(19,6);c.drawPath(a,p);c.drawLine(10,10,10,17,p);c.drawLine(14,10,14,17,p);break;
        case "share":c.drawCircle(5,12,3,p);c.drawCircle(19,5,3,p);c.drawCircle(19,19,3,p);c.drawLine(8,11,16,6,p);c.drawLine(8,13,16,18,p);break;
        case "check":a.moveTo(4,12);a.lineTo(9,17);a.lineTo(20,6);c.drawPath(a,p);break;
        case "lock":c.drawRoundRect(5,10,19,22,2,2,p);c.drawArc(8,2,16,16,180,180,false,p);c.drawLine(12,15,12,18,p);break;
        default:c.drawRoundRect(5,2,19,22,2,2,p);c.drawLine(8,8,16,8,p);c.drawLine(8,12,16,12,p);c.drawLine(8,16,13,16,p);break;
        }c.restoreToCount(s);
    }
}
