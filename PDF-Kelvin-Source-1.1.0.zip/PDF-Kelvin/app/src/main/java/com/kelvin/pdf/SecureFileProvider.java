package com.kelvin.pdf;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

public class SecureFileProvider extends ContentProvider {
    public boolean onCreate() { return true; }
    private File resolve(Uri uri) throws FileNotFoundException {
        try {
            List<String> s=uri.getPathSegments();
            File base; File result;
            if(s.size()==2 && s.get(0).equals("capture") && s.get(1).equals("photo.jpg")) {
                base=new File(getContext().getCacheDir(),"capture"); base.mkdirs(); result=new File(base,"photo.jpg");
            } else if(s.size()==2 && s.get(0).equals("pdf") && s.get(1).matches("[A-Za-z0-9_-]+")) {
                base=new File(getContext().getFilesDir(),"documents"); result=new File(new File(base,s.get(1)),"document.pdf");
            } else throw new FileNotFoundException("Unsupported file");
            if(!result.getCanonicalPath().startsWith(base.getCanonicalPath()+File.separator)) throw new FileNotFoundException("Invalid path");
            return result;
        } catch(java.io.IOException e) { throw new FileNotFoundException("Invalid file"); }
    }
    public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        File f=resolve(uri);
        boolean capture=uri.getPath().startsWith("/capture/");
        if(!capture && !mode.equals("r")) throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(f,mode.equals("r")?ParcelFileDescriptor.MODE_READ_ONLY:ParcelFileDescriptor.MODE_READ_WRITE|ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE);
    }
    public String getType(Uri uri){ return uri.getPath().startsWith("/capture/")?"image/jpeg":"application/pdf"; }
    public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
        try {
            File f=resolve(uri); String name=f.getName();
            if(getType(uri).equals("application/pdf")) {
                try { name=Storage.readJson(new File(f.getParentFile(),"meta.json")).optString("name","Document")+".pdf"; } catch(Exception ignored){}
            }
            String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor c=new MatrixCursor(columns); Object[] row=new Object[columns.length];
            for(int i=0;i<columns.length;i++){ if(columns[i].equals(OpenableColumns.DISPLAY_NAME))row[i]=name; else if(columns[i].equals(OpenableColumns.SIZE))row[i]=f.length(); }
            c.addRow(row); return c;
        }catch(Exception e){return null;}
    }
    public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
    public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
}
