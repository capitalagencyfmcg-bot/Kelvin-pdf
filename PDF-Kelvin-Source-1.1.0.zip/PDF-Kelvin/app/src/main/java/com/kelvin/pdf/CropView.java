package com.kelvin.pdf;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

public class CropView extends View {
    private final Bitmap image;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final RectF bounds=new RectF(),selection=new RectF();
    private boolean ready=false; private int handle=-1;private float previousX,previousY;
    public CropView(Context c,Bitmap b){super(c);image=b;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setContentDescription("Crop image: drag the corners to select the area to keep");}
    protected void onSizeChanged(int w,int h,int ow,int oh){float s=Math.min((w-32f)/image.getWidth(),(h-32f)/image.getHeight());float iw=image.getWidth()*s,ih=image.getHeight()*s;bounds.set((w-iw)/2,(h-ih)/2,(w+iw)/2,(h+ih)/2);if(!ready){selection.set(bounds);float inset=Math.min(iw,ih)*.04f;selection.inset(inset,inset);ready=true;}}
    protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(17,24,39));p.setColor(Color.WHITE);c.drawBitmap(image,null,bounds,p);p.setColor(0x99000000);c.drawRect(bounds.left,bounds.top,bounds.right,selection.top,p);c.drawRect(bounds.left,selection.bottom,bounds.right,bounds.bottom,p);c.drawRect(bounds.left,selection.top,selection.left,selection.bottom,p);c.drawRect(selection.right,selection.top,bounds.right,selection.bottom,p);p.setColor(0xFF60A5FA);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawRect(selection,p);p.setStrokeWidth(1);for(int i=1;i<=2;i++){float x=selection.left+selection.width()*i/3,y=selection.top+selection.height()*i/3;c.drawLine(x,selection.top,x,selection.bottom,p);c.drawLine(selection.left,y,selection.right,y,p);}p.setStyle(Paint.Style.FILL);for(float[] a:corners())c.drawCircle(a[0],a[1],10,p);}
    private float[][] corners(){return new float[][]{{selection.left,selection.top},{selection.right,selection.top},{selection.right,selection.bottom},{selection.left,selection.bottom}};}
    public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==MotionEvent.ACTION_DOWN){handle=-1;float[][] c=corners();for(int i=0;i<4;i++)if(Math.hypot(x-c[i][0],y-c[i][1])<60){handle=i;break;}if(handle<0&&selection.contains(x,y))handle=4;previousX=x;previousY=y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){x=Math.max(bounds.left,Math.min(bounds.right,x));y=Math.max(bounds.top,Math.min(bounds.bottom,y));float minimum=Math.min(60,Math.min(bounds.width(),bounds.height())*.2f);if(handle==0){selection.left=Math.min(x,selection.right-minimum);selection.top=Math.min(y,selection.bottom-minimum);}if(handle==1){selection.right=Math.max(x,selection.left+minimum);selection.top=Math.min(y,selection.bottom-minimum);}if(handle==2){selection.right=Math.max(x,selection.left+minimum);selection.bottom=Math.max(y,selection.top+minimum);}if(handle==3){selection.left=Math.min(x,selection.right-minimum);selection.bottom=Math.max(y,selection.top+minimum);}if(handle==4){float dx=x-previousX,dy=y-previousY;dx=Math.max(bounds.left-selection.left,Math.min(bounds.right-selection.right,dx));dy=Math.max(bounds.top-selection.top,Math.min(bounds.bottom-selection.bottom,dy));selection.offset(dx,dy);}previousX=x;previousY=y;invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){performClick();return true;}return true;}
    public boolean performClick(){super.performClick();return true;}
    public Bitmap crop(){float sx=image.getWidth()/bounds.width(),sy=image.getHeight()/bounds.height();int x=Math.max(0,Math.round((selection.left-bounds.left)*sx)),y=Math.max(0,Math.round((selection.top-bounds.top)*sy));int w=Math.min(image.getWidth()-x,Math.max(1,Math.round(selection.width()*sx))),h=Math.min(image.getHeight()-y,Math.max(1,Math.round(selection.height()*sy)));return Bitmap.createBitmap(image,x,y,w,h);}
}
