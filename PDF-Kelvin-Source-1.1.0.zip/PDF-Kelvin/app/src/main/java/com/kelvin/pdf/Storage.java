package com.kelvin.pdf;

import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Storage {
    public static final int MAX_PAGES=40;
    public static class Page {
        public String key; public File image, original;
        Page(String k,File i,File o){key=k;image=i;original=o;}
    }
    public static class Doc {
        public File dir; public String id,name; public long created; public int pages; public boolean favorite;
        public File pdf(){return new File(dir,"document.pdf");}
        public File cover(){return new File(dir,"page-000.jpg");}
    }
    public static String id(){return UUID.randomUUID().toString().replace("-","");}
    public static String defaultName(){return "Scan "+new SimpleDateFormat("dd MMM yyyy HH.mm",Locale.getDefault()).format(new Date());}
    public static JSONObject readJson(File f)throws Exception {return new JSONObject(new String(readBytes(f),"UTF-8"));}
    public static byte[] readBytes(File f)throws Exception {try(InputStream in=new FileInputStream(f);ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)o.write(b,0,n);return o.toByteArray();}}
    public static void writeJson(File f,JSONObject j)throws Exception {File tmp=new File(f.getPath()+".tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(j.toString().getBytes("UTF-8"));out.getFD().sync();}if(!tmp.renameTo(f))throw new IOException("Could not save document data");}
    public static void copy(File a,File b)throws Exception {try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){transfer(in,out);}}
    public static void transfer(InputStream in,OutputStream out)throws IOException {byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
    public static void delete(File f){if(f.isDirectory()){File[] c=f.listFiles();if(c!=null)for(File x:c)delete(x);}f.delete();}
    public static void jpg(Bitmap b,File f)throws Exception {File tmp=new File(f.getPath()+".tmp");try(FileOutputStream out=new FileOutputStream(tmp)){if(!b.compress(Bitmap.CompressFormat.JPEG,92,out))throw new IOException("Could not save image");out.getFD().sync();}if(!tmp.renameTo(f))throw new IOException("Could not save image file");}
    public static Bitmap decode(File f,int max){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(f.getPath(),o);o.inSampleSize=1;while(Math.max(o.outWidth,o.outHeight)/o.inSampleSize>max*2)o.inSampleSize*=2;o.inJustDecodeBounds=false;o.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b=BitmapFactory.decodeFile(f.getPath(),o);if(b==null)return null;int side=Math.max(b.getWidth(),b.getHeight());if(side>max){Bitmap s=Bitmap.createScaledBitmap(b,Math.max(1,b.getWidth()*max/side),Math.max(1,b.getHeight()*max/side),true);if(s!=b)b.recycle();b=s;}return b;}
    public static Bitmap oriented(File f,int max)throws Exception {
        Bitmap b=decode(f,max);if(b==null)throw new IOException("This image could not be opened");
        int orientation=new ExifInterface(f.getPath()).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);Matrix m=new Matrix();
        switch(orientation){case 2:m.setScale(-1,1);break;case 3:m.setRotate(180);break;case 4:m.setScale(1,-1);break;case 5:m.setRotate(90);m.postScale(-1,1);break;case 6:m.setRotate(90);break;case 7:m.setRotate(270);m.postScale(-1,1);break;case 8:m.setRotate(270);break;}
        if(!m.isIdentity()){Bitmap r=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);if(r!=b)b.recycle();b=r;}return b;
    }
    public static Page addImage(Context c,Uri uri,File draft)throws Exception {
        File temp=new File(c.getCacheDir(),"import-"+id());
        try {
            try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){if(in==null)throw new IOException("Cannot read selected image");transfer(in,out);}
            Bitmap b=oriented(temp,1800);String k=id();File image=new File(draft,k+".jpg"),original=new File(draft,k+"-original.jpg");
            try{jpg(b,image);copy(image,original);}finally{b.recycle();}return new Page(k,image,original);
        }finally{temp.delete();}
    }
    public static ArrayList<Page> importPdf(Context c,Uri uri,File draft,int limit)throws Exception {
        File temp=new File(c.getCacheDir(),"import-pdf-"+id()+".pdf");ArrayList<Page> result=new ArrayList<>();
        try {
            try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){if(in==null)throw new IOException("Cannot read PDF");transfer(in,out);}
            try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(temp,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)) {
                if(renderer.getPageCount()>limit)throw new IOException("Maximum "+MAX_PAGES+" pages per document. Choose a smaller PDF.");
                for(int i=0;i<renderer.getPageCount();i++)try(PdfRenderer.Page p=renderer.openPage(i)) {
                    float scale=1600f/Math.max(p.getWidth(),p.getHeight());Bitmap b=Bitmap.createBitmap(Math.max(1,Math.round(p.getWidth()*scale)),Math.max(1,Math.round(p.getHeight()*scale)),Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                    String k=id();File image=new File(draft,k+".jpg"),original=new File(draft,k+"-original.jpg");try{jpg(b,image);copy(image,original);}finally{b.recycle();}result.add(new Page(k,image,original));
                }
            }return result;
        }catch(Exception e){for(Page p:result){p.image.delete();p.original.delete();}throw e;}finally{temp.delete();}
    }
    public static void saveDraft(File draft,List<Page> pages,String name,int selected)throws Exception {
        JSONArray a=new JSONArray();for(Page p:pages)a.put(p.key);JSONObject j=new JSONObject().put("name",name).put("selected",selected).put("pages",a);writeJson(new File(draft,"draft.json"),j);
    }
    public static ArrayList<Page> loadDraft(File draft)throws Exception {ArrayList<Page> p=new ArrayList<>();JSONObject j=readJson(new File(draft,"draft.json"));JSONArray a=j.getJSONArray("pages");for(int i=0;i<a.length();i++){String k=a.getString(i);if(!k.matches("[A-Za-z0-9]+"))continue;File f=new File(draft,k+".jpg"),o=new File(draft,k+"-original.jpg");if(f.exists()&&o.exists())p.add(new Page(k,f,o));}return p;}
    public static ArrayList<Doc> documents(File base){ArrayList<Doc> list=new ArrayList<>();File[] dirs=base.listFiles();if(dirs!=null)for(File dir:dirs){try{JSONObject j=readJson(new File(dir,"meta.json"));Doc d=new Doc();d.dir=dir;d.id=dir.getName();d.name=j.getString("name");d.created=j.getLong("created");d.pages=j.getInt("pages");d.favorite=j.optBoolean("favorite");if(d.pdf().exists()&&d.cover().exists())list.add(d);}catch(Exception ignored){}}Collections.sort(list,(a,b)->Long.compare(b.created,a.created));return list;}
    public static void updateDoc(Doc d)throws Exception{JSONObject j=new JSONObject().put("name",d.name).put("created",d.created).put("pages",d.pages).put("favorite",d.favorite);writeJson(new File(d.dir,"meta.json"),j);}
    public static Doc createDocument(File base,List<Page> pages,String name,String paper,String quality,String watermark,boolean numbering,boolean landscape)throws Exception {
        if(pages.isEmpty())throw new IOException("Add at least one page");String id=id();File staging=new File(base,".pending-"+id);staging.mkdirs();Doc d=new Doc();d.id=id;d.dir=staging;d.name=name;d.created=System.currentTimeMillis();d.pages=pages.size();
        try {
            for(int i=0;i<pages.size();i++)copy(pages.get(i).image,new File(staging,String.format(Locale.US,"page-%03d.jpg",i)));
            exportPdf(staging,pages.size(),new File(staging,"document.pdf"),paper,quality,watermark,numbering,landscape);
            updateDoc(d);File finalDir=new File(base,id);if(!staging.renameTo(finalDir))throw new IOException("Cannot complete save");d.dir=finalDir;return d;
        }catch(Exception e){delete(staging);throw e;}
    }
    public static void exportPdf(File dir,int count,File out,String paper,String quality,String watermark,boolean numbering,boolean landscape)throws Exception {
        int width=595,height=842;if(paper.equals("Letter")){width=612;height=792;}if(landscape){int t=width;width=height;height=t;}
        int resolution=quality.equals("Compact")?1000:quality.equals("Standard")?1400:1800;
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        PdfDocument pdf=new PdfDocument();
        try {
            for(int i=0;i<count;i++){
                Bitmap b=decode(new File(dir,String.format(Locale.US,"page-%03d.jpg",i)),resolution);if(b==null)throw new IOException("Missing document page");
                PdfDocument.Page p=pdf.startPage(new PdfDocument.PageInfo.Builder(width,height,i+1).create());Canvas canvas=p.getCanvas();canvas.drawColor(Color.WHITE);
                float m=24,footer=numbering?18:0;float scale=Math.min((width-2*m)/b.getWidth(),(height-2*m-footer)/b.getHeight());float w=b.getWidth()*scale,h=b.getHeight()*scale;canvas.drawBitmap(b,null,new RectF((width-w)/2,(height-footer-h)/2,(width+w)/2,(height-footer+h)/2),paint);b.recycle();
                if(!watermark.trim().isEmpty()){canvas.save();canvas.rotate(-35,width/2f,height/2f);Paint wp=new Paint(Paint.ANTI_ALIAS_FLAG);wp.setColor(Color.argb(60,40,65,95));wp.setTextAlign(Paint.Align.CENTER);wp.setTypeface(Typeface.DEFAULT_BOLD);wp.setTextSize(Math.min(44,(width-40)/Math.max(1,watermark.length())*1.7f));canvas.drawText(watermark,width/2f,height/2f,wp);canvas.restore();}
                if(numbering){Paint np=new Paint(Paint.ANTI_ALIAS_FLAG);np.setColor(Color.GRAY);np.setTextSize(10);np.setTextAlign(Paint.Align.CENTER);canvas.drawText((i+1)+" / "+count,width/2f,height-16,np);}
                pdf.finishPage(p);
            }
            try(FileOutputStream os=new FileOutputStream(out)){pdf.writeTo(os);os.getFD().sync();}
        }finally{pdf.close();}
    }
    public static String size(long bytes){return bytes<1024?bytes+" B":bytes<1048576?String.format(Locale.US,"%.0f KB",bytes/1024.0):String.format(Locale.US,"%.1f MB",bytes/1048576.0);}
}
