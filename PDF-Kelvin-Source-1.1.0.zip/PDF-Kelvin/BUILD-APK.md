# PDF Kelvin 1.1.0 — Build instructions

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this project (the files inside `PDF-Kelvin/`).
2. Push the files to the `main` branch, or open **Actions → Build PDF Kelvin APK → Run workflow**.
3. Open the completed workflow run and download the artifact named `PDF-Kelvin-1.1.0-debug-apk`.
4. Extract `app-debug.apk` and install it on an Android device. Android may ask you to allow installation from that source.

The generated debug APK is for testing. For Play Store or public distribution, create a release build signed with your own secure keystore.

## Included in this source update
- Version bumped to 1.1.0.
- About section with owner contact details.
- UPI payment intent for ₹100/year to `7543031310@ybl`.
- Explicit notice that payment verification and subscription activation are not automated.

## Important feature status
The base application rasterizes imported PDFs into page images. PDF-to-Word, PDF-to-Excel table extraction, searchable-text copy, and arbitrary external-PDF splitting are not implemented by this source update. The current base supports image capture/import, image-based PDF creation, merging app-created documents, and editing/extracting pages through its image workflow. Do not advertise unsupported conversion functions as working until they are implemented and tested.
